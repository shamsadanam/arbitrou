
!(function (o, c) {
    var n = c.documentElement,
        t = " w-mod-";
    (n.className += t + "js"), ("ontouchstart" in o || (o.DocumentTouch && c instanceof DocumentTouch)) && (n.className += t + "touch");
})(window, document);



var isMobile = /iPhone|iPad|Android/i.test(navigator.userAgent);
    if (!isMobile) {
        luxy.init({
            wrapper: "#luxy",
            wrapperSpeed: 0.075,
        });
    }


    